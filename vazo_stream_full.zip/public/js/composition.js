// public/js/composition.js
export async function composeEmbeds(rootSelector = '#vazo-root') {
  const root = document.querySelector(rootSelector);
  if (!root) return;

  const fragments = [
    { name: 'header', url: '/api/fragments/header', critical: true, id: 'vazo-header' },
    { name: 'hero', url: '/api/fragments/hero', critical: true, id: 'vazo-hero' },
    { name: 'content', url: '/api/fragments/content?slug=home', critical: true, id: 'vazo-content' },
    { name: 'sidebar', url: '/api/fragments/sidebar', critical: false, id: 'vazo-sidebar' },
    { name: 'footer', url: '/api/fragments/footer', critical: false, id: 'vazo-footer' }
  ];

  fragments.forEach(f => {
    const placeholder = document.createElement('div');
    placeholder.id = f.id;
    placeholder.className = 'vazo-embed-placeholder';
    root.appendChild(placeholder);
  });

  const critical = fragments.filter(f => f.critical);
  await Promise.all(critical.map(f => fetchAndInsert(f)));

  const nonCritical = fragments.filter(f => !f.critical);
  if ('requestIdleCallback' in window) {
    requestIdleCallback(() => nonCritical.forEach(f => fetchAndInsert(f)));
  } else {
    setTimeout(() => nonCritical.forEach(f => fetchAndInsert(f)), 800);
  }

  async function fetchAndInsert(fragment) {
    try {
      const res = await fetch(fragment.url, { credentials: 'same-origin' });
      if (!res.ok) { console.warn('Failed fragment', fragment.name, res.status); return; }
      const html = await res.text();
      const el = document.getElementById(fragment.id);
      if (el) el.innerHTML = html;
    } catch (err) {
      console.error('Error loading fragment', fragment.name, err);
    }
  }
}
