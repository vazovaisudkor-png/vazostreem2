// src/templates/fragment.footer.ts
export function renderFooter(site:any) {
  return `
  <footer class="vazo-footer">
    <div>© ${new Date().getFullYear()} ${escapeHtml(site.title || 'Vazo Stream')}</div>
  </footer>`;
}
function escapeHtml(s=''){ return String(s).replace(/[&<>"']/g, (c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
