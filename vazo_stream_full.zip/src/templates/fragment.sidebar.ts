// src/templates/fragment.sidebar.ts
export function renderSidebar(posts:any) {
  const items = (posts?.posts || []).map((p:any)=>`<li><a href="/post/${encodeURIComponent(p.slug)}">${escapeHtml(p.title)}</a></li>`).join('');
  return `<aside class="vazo-sidebar"><h3>Recent</h3><ul>${items}</ul></aside>`;
}
function escapeHtml(s=''){ return String(s).replace(/[&<>"']/g, (c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
