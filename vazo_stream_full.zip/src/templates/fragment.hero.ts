// src/templates/fragment.hero.ts
export function renderHero(featured:any) {
  const post = featured?.posts?.[0];
  if (!post) return `<section class="vazo-hero"><p>No featured content</p></section>`;
  return `
  <section class="vazo-hero">
    <a href="/post/${encodeURIComponent(post.slug)}">
      <h1>${escapeHtml(post.title)}</h1>
      <p>${escapeHtml(post.excerpt || '')}</p>
    </a>
  </section>`;
}
function escapeHtml(s='') { return String(s).replace(/[&<>"']/g, (c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
