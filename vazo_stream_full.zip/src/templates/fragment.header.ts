// src/templates/fragment.header.ts
export function renderHeader(site:any) {
  const nav = site.navigation || [];
  const navHtml = nav.map((i:any) => `<a href="${escapeHtml(i.url)}">${escapeHtml(i.label)}</a>`).join('');
  return `
  <div class="vazo-header">
    <div class="brand"><a href="/">${escapeHtml(site.title || 'Vazo Stream')}</a></div>
    <nav class="vazo-nav">${navHtml}</nav>
  </div>`;
}
function escapeHtml(str = '') {
  return String(str).replace(/[&<>"']/g, (s) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
}
