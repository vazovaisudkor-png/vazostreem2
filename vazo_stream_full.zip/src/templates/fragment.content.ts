// src/templates/fragment.content.ts
export function renderContent(post:any) {
  if (!post) return '<main class="vazo-content"><p>Content not found</p></main>';
  return `
  <main class="vazo-content">
    <article>
      <h2>${escapeHtml(post.title)}</h2>
      <div class="post-body">${post.html}</div>
    </article>
  </main>`;
}
function escapeHtml(s=''){ return String(s).replace(/[&<>"']/g, (c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
