// src/app/api/fragments/header/route.ts
import { NextResponse } from 'next/server';
import { getSiteSettings } from '@/lib/ghostClient';
import { renderHeader } from '@/templates/fragment.header';

export async function GET() {
  const site = await getSiteSettings();
  const html = renderHeader(site);
  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600'
    }
  });
}
