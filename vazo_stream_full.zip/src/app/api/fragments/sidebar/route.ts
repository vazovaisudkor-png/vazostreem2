// src/app/api/fragments/sidebar/route.ts
import { NextResponse } from 'next/server';
import { getRecent } from '@/lib/ghostClient';
import { renderSidebar } from '@/templates/fragment.sidebar';

export async function GET() {
  const recent = await getRecent({ limit: 6 });
  const html = renderSidebar(recent);
  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=1800'
    }
  });
}
