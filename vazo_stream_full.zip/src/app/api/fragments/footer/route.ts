// src/app/api/fragments/footer/route.ts
import { NextResponse } from 'next/server';
import { getSiteSettings } from '@/lib/ghostClient';
import { renderFooter } from '@/templates/fragment.footer';

export async function GET() {
  const site = await getSiteSettings();
  const html = renderFooter(site);
  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=86400'
    }
  });
}
