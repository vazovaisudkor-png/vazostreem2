// src/app/api/fragments/hero/route.ts
import { NextResponse } from 'next/server';
import { getFeatured } from '@/lib/ghostClient';
import { renderHero } from '@/templates/fragment.hero';

export async function GET() {
  const featured = await getFeatured();
  const html = renderHero(featured);
  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=300'
    }
  });
}
