// src/app/api/fragments/content/route.ts
import { NextResponse } from 'next/server';
import { getPostBySlug } from '@/lib/ghostClient';
import { renderContent } from '@/templates/fragment.content';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const slug = url.searchParams.get('slug') || 'home';
  try {
    const r = await getPostBySlug(slug);
    const post = r?.posts?.[0];
    const html = renderContent(post);
    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400'
      }
    });
  } catch (e) {
    return new NextResponse('<main class="vazo-content"><p>Content error</p></main>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
  }
}
