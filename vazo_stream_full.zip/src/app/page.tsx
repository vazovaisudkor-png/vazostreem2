// src/app/page.tsx
import React from 'react';

export default function Page() {
  return (
    <html>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>Vazo Stream</title>
        <link rel="stylesheet" href="/styles.css" />
        <link rel="preload" href="/api/fragments/header" as="fetch" />
        <link rel="preload" href="/api/fragments/hero" as="fetch" />
      </head>
      <body>
        <div id="vazo-root"></div>
        <script type="module">
          {`import { composeEmbeds } from '/js/composition.js'; composeEmbeds('#vazo-root');`}
        </script>
      </body>
    </html>
  );
}
