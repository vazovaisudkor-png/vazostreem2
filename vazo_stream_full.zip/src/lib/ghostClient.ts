// src/lib/ghostClient.ts
const GHOST_URL = process.env.GHOST_API_URL || process.env.NEXT_PUBLIC_GHOST_API_URL || '';
const GHOST_KEY = process.env.NEXT_PUBLIC_GHOST_API_KEY || '';

async function fetchGhost(path: string, params: Record<string,string|number> = {}) {
  const base = GHOST_URL.replace(/\/$/, '');
  const url = new URL(`/ghost/api/content/${path}/`, base);
  if (GHOST_KEY) url.searchParams.set('key', GHOST_KEY);
  Object.entries(params).forEach(([k,v]) => url.searchParams.set(k, String(v)));
  const res = await fetch(url.toString(), { next: { revalidate: 60 } });
  if (!res.ok) throw new Error(`Ghost fetch failed ${res.status}`);
  return res.json();
}

export async function getSiteSettings() {
  try {
    const r = await fetchGhost('site', {});
    return r?.site || { title: 'Vazo Stream', navigation: [] };
  } catch (e) {
    return { title: 'Vazo Stream', navigation: [] };
  }
}

export async function getFeatured() {
  return fetchGhost('posts', { filter: 'featured:true', include: 'authors,tags', limit: 1 });
}

export async function getRecent({limit = 6} = {}) {
  return fetchGhost('posts', { limit, include: 'authors,tags' });
}

export async function getPostBySlug(slug: string) {
  return fetchGhost(`posts/slug/${encodeURIComponent(slug)}`, { include: 'authors,tags' });
}
